const ComentariosModel = require('../models/comentarios');
const mongoose = require('mongoose')

class ComentariosController {

    async agregar(req, res) {
        try {
            const body = req.body;

            //Validamos que esten completos los campos
            if (!body.nombre || !body.correo || !body.comentario) {
                return res.status(400).json({
                    ok: false, mensaje: 'Debes completar todos los campos solicitados'
                })
            }

            // Creamos el nuevo Comentario
            const nuevoComentario = {
                nombre: body.nombre, correo: body.correo, comentario: body.comentario
            }

            const comentarioCreado = await ComentariosModel.create(
                nuevoComentario
            )

            if (!comentarioCreado) {
                return res.status(400).json({
                    ok: false,
                    mensaje: 'Hubo un error al crear el nuevo Comentario',
                })
            }
            res.status(200).json({
                ok: true,
                Comentario: comentarioCreado,
            })

        } catch (error) {
            console.error('Error al crear el nuevo Comentario:', error)
            return res.status(500).json({
                ok: false,
                mensaje: 'Hubo un error al crear el nuevo Comentario',
            })
        }
    }

    async mostrar(req, res) {
        try {
            const totalComentarios = await ComentariosModel.find().select(
                '_id nombre correo comentario'
            )
            return res.status(200).json({
                ok: true,
                totalComentarios
            })
        } catch (error) {
            console.error('Error al mostrar los Comentarios:', error)
            return res.status(500).json({
                ok: false,
                mensaje: 'Hubo un error al mostrar los Comentarios',
            })
        }
    }

    async eliminar(req, res) {
        try {
            const { comentarioId } = req.params;

            //validacion del ID para que sea como el ID de Mongoose
            if (!mongoose.isValidObjectId(comentarioId)) {
                return res.status(400).json({
                    ok: false,
                    mensaje: 'ID no válido',
                })
            }

            // Eliminamos el Animal seleccionado
            const comentarioEliminado = await ComentariosModel.findByIdAndDelete(comentarioId)
            if (!comentarioEliminado) {
                return res.status(400).json({
                    ok: false,
                    mensaje: 'Hubo un error al eliminar el Comentario',
                })
            }

            res.status(200).json({
                ok: true,
                comentarioEliminado,
                mensaje: 'Comentario eliminado',
            })
        } catch (error) {
            console.error('Error al eliminar los Comentarios:', error)
            return res.status(500).json({
                ok: false,
                mensaje: 'Hubo un error al eliminar los Comentarios',
            })
        }
    }
}

const comentariosController = new ComentariosController();
module.exports = comentariosController;