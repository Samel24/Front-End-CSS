const mongoose = require('mongoose')

const Schema = mongoose.Schema;
const ObjectId = Schema.ObjectId;

const ComentariosSchema = new Schema({
  id: ObjectId,
  nombre: {
    type: String,
    required: true,
    match: /[a-z]/,
  },
  correo: {
    type: String,
    required: true,
  },
  comentario: {
    type: String,
    required: true,
  }

});

const ComentariosModel = mongoose.model('comentarios', ComentariosSchema)
module.exports = ComentariosModel