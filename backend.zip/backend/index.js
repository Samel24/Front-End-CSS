const startServer = require('./src/server');
startServer();