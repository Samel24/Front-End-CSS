const publicar = document.getElementById('publicar-comentario')

function enviarData(comentario) {
    fetch('http://localhost:3060/comentarios/agregar', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json;charset=utf-8'
        },
        body: JSON.stringify(comentario)
    }).then(response => response.text())
        .then(data => {
            /** Procesar los datos **/
            datos = JSON.parse(data)
            console.log(datos)
        });
}

function recibirDatos() {
    const nombre = document.getElementById('nombre')
    const correo = document.getElementById('correo')
    const comentario = document.getElementById('comentario')


    if (nombre.value.trim() == 0 || correo.value.trim() == 0 || comentario.value.trim() == 0) {
        return alert('Has ingresado datos no validos')
    }

    coment = {
        "nombre": nombre.value,
        "correo": correo.value,
        "comentario": comentario.value
    }

    console.log(JSON.stringify(coment))

    nombre.value = '';
    correo.value = '';
    comentario.value = '';

    enviarData(coment)
}

publicar.addEventListener('click', (e) => {
    e.preventDefault()
    recibirDatos()
})