const lista = document.querySelector(".comentarios")
let datos = []

function introducirComentarios(comentarios) {

    comentarios.forEach(comentario => {
        const article = document.createElement("article")
        article.className = "comenatrio"
        lista.appendChild(article);

        const h3 = document.createElement("h3")
        h3.className = "links"
        h3.textContent = comentario.nombre
        article.appendChild(h3);

        const h4 = document.createElement("h4")
        h4.className = "subtitulo-secundario"
        h4.textContent = comentario.correo
        article.appendChild(h4);

        const p = document.createElement("p")
        p.className = "texto"
        p.textContent = comentario.comentario
        article.appendChild(p);
    });
}

function traerData() {
    while (lista.firstChild) {
        lista.removeChild(lista.firstChild);
    }

    fetch('http://localhost:3060/comentarios/', {
        method: 'GET',
        headers: {
            'Content-Type': 'application/json;charset=utf-8'
        }
    }).then(response => response.text())
        .then(data => {
            /** Procesar los datos **/
            datos = JSON.parse(data)
            console.log(datos)
            introducirComentarios(datos.totalComentarios)
        });
}

traerData()