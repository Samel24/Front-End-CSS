var express = require('express');
var router = express.Router();
// En esta línea llamamos al controlador de animales
const comentariosController = require('../controllers/comentarios.controller');

router.post('/agregar', comentariosController.agregar);
router.get('/', comentariosController.mostrar);
router.delete('/eliminar/:animalId', comentariosController.eliminar);

module.exports = router;
